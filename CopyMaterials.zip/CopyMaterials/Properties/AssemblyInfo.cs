﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CopyMaterials")]
[assembly: AssemblyProduct("CopyMaterials")]
[assembly: AssemblyCopyright("© Leo")]
[assembly: ComVisible(false)]
[assembly: Guid("ecf85f0c-86cd-4f7e-9b68-f4e4063b7e37")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]